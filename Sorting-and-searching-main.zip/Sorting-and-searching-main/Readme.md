This algorithm sorts numbers using insertion sort.

it begins by requesting for the numbers to be sorted.

The numbers are then sorted using insertion method.

it uses 2 nested loops. It starts at index 1 (which is the second item in the array). it then compares it to the item on its left, if smaller, it moves it left. it continues to move it left until no smaller item is to the left of the selected item. Then it goes the next item and repeats the process until all items are sorted in ascending order.
